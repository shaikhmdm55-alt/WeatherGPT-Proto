package com.example.logic

import com.example.data.AgriDecision
import com.example.data.AlertSeverity
import com.example.data.Language
import com.example.data.WeatherTelemetry

object AgriDecisionEngine {

    fun evaluate(telemetry: WeatherTelemetry, lang: Language): AgriDecision {
        val wind = telemetry.windSpeed
        val rain = telemetry.rainProbability

        return when {
            // Rule 3: Squall / Storm Warning (Highest Priority)
            wind > 45.0 -> {
                when (lang) {
                    Language.HINDI -> AgriDecision(
                        severity = AlertSeverity.STORM_ALERT,
                        statusTitle = "🚨 आंधी-तूफान की चेतावनी (STORM ALERT)",
                        badgeIcon = "🚨",
                        verdictSummary = "खेत से तुरंत बाहर निकलें! तेज आंधी और आकाशीय बिजली का खतरा।",
                        actionSentences = listOf(
                            "खेतों में काम तुरंत बंद करें और खुले में न रहें।",
                            "ट्यूबवेल और बिजली के कनेक्शन तुरंत बंद करें।",
                            "मवेशियों को सुरक्षित पक्के शेड में बांधें।"
                        ),
                        economicBenefit = null,
                        operationalWindow = "अति-गंभीर: तुरंत सुरक्षित स्थान पर जाएं",
                        fullVoiceScript = "सावधान! हवा की रफ्तार ${wind.toInt()} किलोमीटर प्रति घंटा है। आंधी-तूफान की गंभीर चेतावनी है। कृपया तुरंत खेत खाली करें, ट्यूबवेल की बिजली बंद करें और मवेशियों को सुरक्षित स्थान पर ले जाएं।"
                    )
                    Language.GUJARATI -> AgriDecision(
                        severity = AlertSeverity.STORM_ALERT,
                        statusTitle = "🚨 વાવાઝોડાની ચેતવણી (STORM ALERT)",
                        badgeIcon = "🚨",
                        verdictSummary = "ખેતરમાંથી તરત બહાર નીકળો! ભારે પવન અને વીજળીનું જોખમ.",
                        actionSentences = listOf(
                            "ખેતીકામ તાત્કાલિક બંધ કરો અને ખુલ્લા ખેતરમાં ન રહો.",
                            "બોરવેલ અને મોટરનું વીજ જોડાણ બંધ કરો.",
                            "પશુઓને સુરક્ષિત પાકા મકાન કે શેડમાં બાંધો."
                        ),
                        economicBenefit = null,
                        operationalWindow = "અતિ-ગંભીર: તાત્કાલિક સુરક્ષિત આશ્રય લો",
                        fullVoiceScript = "સાવધાન ખેડૂત મિત્રો! પવનની ઝડપ ${wind.toInt()} કિલોમીટર પ્રતિ કલાક છે. ભારે વાવાઝોડાનું જોખમ છે. તાત્કાલિક ખેતરમાંથી બહાર નીકળો, વીજળી બંધ કરો અને પશુઓને પાકા શેડમાં રાખો."
                    )
                    Language.ENGLISH -> AgriDecision(
                        severity = AlertSeverity.STORM_ALERT,
                        statusTitle = "🚨 CONVECTIVE STORM ALERT",
                        badgeIcon = "🚨",
                        verdictSummary = "Vacate fields immediately! Severe squall and lightning danger.",
                        actionSentences = listOf(
                            "Vacate fields immediately and seek shelter.",
                            "Shut off tube-well electricity and high-voltage connections.",
                            "Move livestock into concrete shelters or covered sheds."
                        ),
                        economicBenefit = null,
                        operationalWindow = "Critical: Seek Immediate Shelter",
                        fullVoiceScript = "Warning! Wind speed is ${wind.toInt()} km/h. Convective storm alert active. Vacate fields immediately, shut off tube-well electricity, and secure all livestock in concrete shelters."
                    )
                }
            }

            // Rule 2: Urgent Harvest Alert
            rain > 70 || wind > 40.0 -> {
                when (lang) {
                    Language.HINDI -> AgriDecision(
                        severity = AlertSeverity.URGENT_HARVEST,
                        statusTitle = "⚠️ तत्काल फसल कटाई चेतावनी (URGENT HARVEST)",
                        badgeIcon = "⚠️",
                        verdictSummary = "पकी फसलों की कटाई 6 से 12 घंटों के भीतर पूरी करें।",
                        actionSentences = listOf(
                            "बारिश की संभावना ${rain}% और हवा ${wind.toInt()} किमी/घंटा है।",
                            "फसल गिरने (लॉजिंग) और दाना सड़ने से बचाने के लिए तुरंत कटाई करें।",
                            "कटी हुई उपज को तिरपाल से ढकें या गोदाम में रखें।"
                        ),
                        economicBenefit = "फसल बर्बादी से सुरक्षा (~₹12,000–₹25,000/एकड़)",
                        operationalWindow = "कटाई समय: अगले 6–12 घंटे",
                        fullVoiceScript = "चेतावनी! बारिश की संभावना ${rain} प्रतिशत है। फसल गिरने और बीज सड़ने से बचाने के लिए पकी फसलों की कटाई अगले 6 से 12 घंटे में पूरी कर लें।"
                    )
                    Language.GUJARATI -> AgriDecision(
                        severity = AlertSeverity.URGENT_HARVEST,
                        statusTitle = "⚠️ તાત્કાલિક પાક લણણી ચેતવણી (URGENT HARVEST)",
                        badgeIcon = "⚠️",
                        verdictSummary = "તૈયાર પાક 6 થી 12 કલાકમાં લણી લો.",
                        actionSentences = listOf(
                            "વરસાદની સંભાવના ${rain}% અને પવન ${wind.toInt()} કિમી/કલાક છે.",
                            "પાક ઢળી પડવાથી અને દાણા બગડતા અટકાવવા ઝડપથી લણણી કરો.",
                            "લણેલા પાકને તાલપત્રીથી ઢાંકીને ગોડાઉનમાં ખસેડો."
                        ),
                        economicBenefit = "પાક બગાડ સામે રક્ષણ (~₹12,000–₹25,000/એકર)",
                        operationalWindow = "લણણી વિન્ડો: આગામી 6–12 કલાક",
                        fullVoiceScript = "સાવચેત રહો! વરસાદની શક્યતા ${rain} ટકા છે. પાક નમી પડવા અને સડી જતા અટકાવવા માટે 6 થી 12 કલાકની અંદર પાકની લણણી કરી લો."
                    )
                    Language.ENGLISH -> AgriDecision(
                        severity = AlertSeverity.URGENT_HARVEST,
                        statusTitle = "⚠️ URGENT HARVEST WINDOW",
                        badgeIcon = "⚠️",
                        verdictSummary = "Reap mature crops within 6–12 hours.",
                        actionSentences = listOf(
                            "Rain probability is ${rain}% with winds at ${wind.toInt()} km/h.",
                            "Harvest ripe standing crops immediately to prevent field lodging.",
                            "Protect harvested bundles with tarpaulins to prevent seed germination."
                        ),
                        economicBenefit = "Prevents crop loss (~₹12,000–₹25,000/acre)",
                        operationalWindow = "Harvest Window: Next 6–12 Hours",
                        fullVoiceScript = "Attention! Rain probability is ${rain} percent. Reap mature crops within 6 to 12 hours to prevent field lodging and seed rot."
                    )
                }
            }

            // Rule 1A: Spraying Hazard
            wind > 15.0 || rain > 30 -> {
                val reasonEn = if (wind > 15.0 && rain > 30) "High winds (${wind.toInt()} km/h) & Rain risk (${rain}%)"
                else if (wind > 15.0) "High winds (${wind.toInt()} km/h > 15 km/h limit)"
                else "Rain probability (${rain}% > 30% limit)"

                when (lang) {
                    Language.HINDI -> AgriDecision(
                        severity = AlertSeverity.SPRAY_MORATORIUM,
                        statusTitle = "🛑 खतरा: छिड़काव पर रोक (SPRAYING MORATORIUM)",
                        badgeIcon = "🛑",
                        verdictSummary = "आज कीटनाशक या खाद का छिड़काव बिल्कुल न करें।",
                        actionSentences = listOf(
                            "हवा की गति (${wind.toInt()} किमी/घंटा) या बारिश की संभावना (${rain}%) अधिक है।",
                            "तेज हवा और बारिश से दवा धुल जाएगी और जमीन में बहकर बेकार हो जाएगी।",
                            "छिड़काव टालने से आपके इनपुट खर्च की बचत होगी।"
                        ),
                        economicBenefit = "लागत बचत: ~₹4,000–₹7,500 प्रति एकड़",
                        operationalWindow = "छिड़काव स्थिति: तत्काल रोक (Moratorium)",
                        fullVoiceScript = "ध्यान दें किसान भाई! आज कीटनाशक या खाद का छिड़काव बिल्कुल न करें। तेज हवा और बारिश से दवा बह जाएगी। छिड़काव टालकर आप प्रति एकड़ 4 हजार से साढ़े 7 हजार रुपये बचाएंगे।"
                    )
                    Language.GUJARATI -> AgriDecision(
                        severity = AlertSeverity.SPRAY_MORATORIUM,
                        statusTitle = "🛑 જોખમ: દવાનો છંટકાવ બંધ રાખો (SPRAYING MORATORIUM)",
                        badgeIcon = "🛑",
                        verdictSummary = "આજે જંતુનાશક કે ખાતરનો છંટકાવ કરશો નહીં.",
                        actionSentences = listOf(
                            "પવનની ઝડપ (${wind.toInt()} કિમી/કલાક) અથવા વરસાદની શક્યતા (${rain}%) વધુ છે.",
                            "પવન અને વરસાદથી મોંઘી દવા ધોવાઈ જશે અને વ્યર્થ જશે.",
                            "છંટકાવ મુલતવી રાખવાથી ખર્ચમાં મોટી બચત થશે."
                        ),
                        economicBenefit = "ખર્ચ બચત: ~₹4,000–₹7,500 પ્રતિ એકર",
                        operationalWindow = "છંટકાવ સ્થિતિ: તાત્કાલિક મોકૂફી (Moratorium)",
                        fullVoiceScript = "ખેડૂત મિત્રો ધ્યાન આપો! આજે જંતુનાશક કે ખાતરનો છંટકાવ કરશો નહીં. પવન અને વરસાદથી દવા ધોવાઈ જશે. છંટકાવ ટાળવાથી એકરે 4 થી સાડા 7 હજાર રૂપિયાની બચત થશે."
                    )
                    Language.ENGLISH -> AgriDecision(
                        severity = AlertSeverity.SPRAY_MORATORIUM,
                        statusTitle = "🛑 HAZARD: SPRAYING MORATORIUM",
                        badgeIcon = "🛑",
                        verdictSummary = "Do NOT spray pesticides or fertilizers today.",
                        actionSentences = listOf(
                            "$reasonEn makes spraying hazardous.",
                            "High winds and incoming rain will wash chemicals into runoff.",
                            "Postponing spray preserves input chemicals and saves farm budget."
                        ),
                        economicBenefit = "Direct Saving: ~₹4,000–₹7,500 / acre",
                        operationalWindow = "Spray Status: Immediate Moratorium",
                        fullVoiceScript = "Alert! Do NOT spray pesticides or fertilizers today. High winds and incoming rain will wash chemicals into runoff, wasting input costs. Postponing saves approximately 4,000 to 7,500 rupees per acre."
                    )
                }
            }

            // Rule 1B: Safe Spraying Window
            else -> {
                when (lang) {
                    Language.HINDI -> AgriDecision(
                        severity = AlertSeverity.SAFE,
                        statusTitle = "✅ सुरक्षित छिड़काव समय (SAFE SPRAYING)",
                        badgeIcon = "✅",
                        verdictSummary = "पत्तियों पर स्प्रे और खाद देने के लिए मौसम उत्तम है।",
                        actionSentences = listOf(
                            "हवा शांत है (${wind.toInt()} किमी/घंटा) और बारिश का खतरा केवल ${rain}% है।",
                            "दवा पत्तों पर अच्छी तरह टिकेगी और शत-प्रतिशत असर करेगी।",
                            "सुबह 7-11 बजे या शाम 4-6 बजे के बीच छिड़काव करें।"
                        ),
                        economicBenefit = "अधिकतम कीटनाशक प्रभावशीलता",
                        operationalWindow = "सुरक्षित समय: अगले 6 घंटे अनुकूल",
                        fullVoiceScript = "खुशखबरी! छिड़काव के लिए सुरक्षित समय है। हवा शांत है और बारिश की संभावना केवल ${rain} प्रतिशत है। आप सुरक्षित रूप से फोलियर स्प्रे कर सकते हैं।"
                    )
                    Language.GUJARATI -> AgriDecision(
                        severity = AlertSeverity.SAFE,
                        statusTitle = "✅ સુરક્ષિત છંટકાવ વિન્ડો (SAFE SPRAYING)",
                        badgeIcon = "✅",
                        verdictSummary = "પાક પર દવાનો છંટકાવ કરવા માટે શ્રેષ્ઠ વાતાવરણ છે.",
                        actionSentences = listOf(
                            "પવન ધીમો છે (${wind.toInt()} કિમી/કલાક) અને વરસાદની શક્યતા માત્ર ${rain}% છે.",
                            "છંટકાવ કરેલી દવા પાંદડા પર બરાબર ચોંટી જશે.",
                            "સવારે 7-11 અથવા સાંજે 4-6 વચ્ચે છંટકાવ કરવો ઉત્તમ રહેશે."
                        ),
                        economicBenefit = "દવા અને ખાતરની પૂર્ણ અસરકારકતા",
                        operationalWindow = "સુરક્ષિત વિન્ડો: આગામી 6 કલાક અનુકૂળ",
                        fullVoiceScript = "ખેડૂત મિત્રો! દવાનો છંટકાવ કરવા માટે ઉત્તમ સમય છે. પવન શાંત છે અને વરસાદનું કોઈ જોખમ નથી. તમે નિશ્ચિંત થઈને છંટકાવ કરી શકો છો."
                    )
                    Language.ENGLISH -> AgriDecision(
                        severity = AlertSeverity.SAFE,
                        statusTitle = "✅ SAFE SPRAYING WINDOW",
                        badgeIcon = "✅",
                        verdictSummary = "Safe to apply foliar spray and liquid fertilizers.",
                        actionSentences = listOf(
                            "Wind is calm (${wind.toInt()} km/h) and rain probability is low (${rain}%).",
                            "Droplets will settle uniformly on crop foliage without drift.",
                            "Recommended spray hours: early morning or late afternoon."
                        ),
                        economicBenefit = "Optimal Chemical Absorption & Efficacy",
                        operationalWindow = "Safe Window: Next 6 Hours Favorable",
                        fullVoiceScript = "Safe spraying window active. Wind is calm at ${wind.toInt()} km/h and rain probability is low at ${rain} percent. Safe to apply foliar spray today."
                    )
                }
            }
        }
    }
}
