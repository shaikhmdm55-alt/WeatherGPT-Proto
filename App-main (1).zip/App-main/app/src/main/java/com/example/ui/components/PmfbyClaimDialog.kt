package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.Language
import com.example.data.PmfbyClaim
import com.example.data.WeatherTelemetry
import com.example.ui.theme.AgriDarkForest
import com.example.ui.theme.AgriDeepGreen
import com.example.ui.theme.AgriEmerald
import com.example.ui.theme.AgriLeafGreen
import com.example.ui.theme.AgriMintAccent
import com.example.ui.theme.AgriPaleGreen
import com.example.ui.theme.GoldWheat
import com.example.ui.theme.HazardRed
import com.example.ui.theme.SafeEmerald
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PmfbyClaimDialog(
    telemetry: WeatherTelemetry,
    language: Language,
    onDismiss: () -> Unit,
    onSubmit: (farmerName: String, mobile: String, crop: String, cause: String) -> Unit
) {
    var farmerName by remember { mutableStateOf("Ramesh Patel") }
    var mobileNumber by remember { mutableStateOf("98250 84721") }

    val cropOptions = when (language) {
        Language.HINDI -> listOf("कपास (Cotton)", "गेहूं (Wheat)", "धान (Paddy)", "सोयाबीन (Soybean)", "गन्ना (Sugarcane)")
        Language.GUJARATI -> listOf("કપાસ (Cotton)", "ઘઉં (Wheat)", "ડાંગર (Paddy)", "મગફળી (Groundnut)", "શેરડી (Sugarcane)")
        Language.ENGLISH -> listOf("Cotton", "Wheat", "Paddy", "Soybean", "Groundnut", "Sugarcane")
    }
    var selectedCrop by remember { mutableStateOf(cropOptions[0]) }

    val causeOptions = when (language) {
        Language.HINDI -> listOf("अत्यधिक बारिश / जलभराव (Inundation)", "तेज आंधी / हवा से नुकसान (Gale)", "ओलावृष्टि (Hailstorm)", "कीट प्रकोप (Pest Attack)")
        Language.GUJARATI -> listOf("ભારે વરસાદ / પાણી ભરાવું (Inundation)", "વાવાઝોડું / પવનથી નુકસાન (Gale)", "કરા પડવા (Hailstorm)", "રોગ-જીવાત (Pest Attack)")
        Language.ENGLISH -> listOf("Inundation / Waterlogging", "Squall / Gale Wind Damage", "Hailstorm", "Post-Harvest Rain Damage")
    }
    var selectedCause by remember { mutableStateOf(causeOptions[0]) }

    var photoAttached by remember { mutableStateOf(true) }

    val formattedTime = remember {
        val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH)
        sdf.format(Date(telemetry.timestamp))
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .testTag("pmfby_claim_modal")
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .border(2.dp, AgriMintAccent, RoundedCornerShape(24.dp)),
            colors = CardDefaults.cardColors(containerColor = AgriDarkForest),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(AgriMintAccent),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = "PMFBY Camera",
                                tint = AgriDarkForest,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "PMFBY Damage Report",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    color = Color.White,
                                    fontSize = 17.sp
                                )
                            )
                            Text(
                                text = "Pradhan Mantri Fasal Bima Yojana",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = AgriMintAccent,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(Color.DarkGray)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Farmer Name
                Text(
                    text = when (language) {
                        Language.HINDI -> "किसान का नाम (Farmer Name):"
                        Language.GUJARATI -> "ખેડૂતનું નામ (Farmer Name):"
                        Language.ENGLISH -> "Farmer Name:"
                    },
                    style = MaterialTheme.typography.labelMedium.copy(color = AgriPaleGreen, fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = farmerName,
                    onValueChange = { farmerName = it },
                    modifier = Modifier
                        .testTag("pmfby_farmer_name_input")
                        .fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF040D0A),
                        unfocusedContainerColor = Color(0xFF040D0A),
                        focusedBorderColor = AgriMintAccent,
                        unfocusedBorderColor = AgriLeafGreen
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Mobile Number
                Text(
                    text = when (language) {
                        Language.HINDI -> "मोबाइल नंबर (Mobile / Aadhaar):"
                        Language.GUJARATI -> "મોબાઇલ નંબર (Mobile / Aadhaar):"
                        Language.ENGLISH -> "Mobile Number / Aadhaar:"
                    },
                    style = MaterialTheme.typography.labelMedium.copy(color = AgriPaleGreen, fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = mobileNumber,
                    onValueChange = { mobileNumber = it },
                    modifier = Modifier
                        .testTag("pmfby_mobile_input")
                        .fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF040D0A),
                        unfocusedContainerColor = Color(0xFF040D0A),
                        focusedBorderColor = AgriMintAccent,
                        unfocusedBorderColor = AgriLeafGreen
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Crop Selection
                Text(
                    text = when (language) {
                        Language.HINDI -> "फसल का नाम (Select Crop):"
                        Language.GUJARATI -> "પાકનું નામ (Select Crop):"
                        Language.ENGLISH -> "Select Damaged Crop:"
                    },
                    style = MaterialTheme.typography.labelMedium.copy(color = AgriPaleGreen, fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(6.dp))
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    cropOptions.forEach { crop ->
                        val isSelected = crop == selectedCrop
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (isSelected) AgriMintAccent else Color(0xFF1B4332))
                                .border(1.dp, if (isSelected) GoldWheat else AgriLeafGreen, RoundedCornerShape(16.dp))
                                .clickable { selectedCrop = crop }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = crop,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Normal,
                                color = if (isSelected) AgriDarkForest else Color.White
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Cause Selection
                Text(
                    text = when (language) {
                        Language.HINDI -> "नुकसान का कारण (Loss Cause):"
                        Language.GUJARATI -> "નુકસાનનું કારણ (Loss Cause):"
                        Language.ENGLISH -> "Cause of Loss:"
                    },
                    style = MaterialTheme.typography.labelMedium.copy(color = AgriPaleGreen, fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(6.dp))
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    causeOptions.forEach { cause ->
                        val isSelected = cause == selectedCause
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (isSelected) GoldWheat else Color(0xFF1B4332))
                                .border(1.dp, if (isSelected) Color.White else AgriLeafGreen, RoundedCornerShape(16.dp))
                                .clickable { selectedCause = cause }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = cause,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Normal,
                                color = if (isSelected) AgriDarkForest else Color.White
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Camera & Automated Watermark Preview Box
                Text(
                    text = "📸 Geotagged Photo & Telemetry Watermark Preview:",
                    style = MaterialTheme.typography.labelMedium.copy(color = GoldWheat, fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(6.dp))

                // Damaged crop photo canvas representation with embedded official watermark overlay
                Box(
                    modifier = Modifier
                        .testTag("pmfby_photo_watermark_preview")
                        .fillMaxWidth()
                        .height(160.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0xFF264653), Color(0xFF2A9D8F), Color(0xFF1E3A2F))
                            )
                        )
                        .border(1.5.dp, GoldWheat, RoundedCornerShape(16.dp))
                        .clickable { photoAttached = !photoAttached }
                ) {
                    // Visual farm backdrop representation
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Watermark Top: GPS & District
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "📍 LAT ${telemetry.district.lat} | LON ${telemetry.district.lon}",
                                fontSize = 10.sp,
                                color = Color.Yellow,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = telemetry.district.localizedName(language),
                                fontSize = 10.sp,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.weight(1f))

                        // Watermark Bottom: Time, Wind, Rain, Temp, Official Code
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.Black.copy(alpha = 0.75f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = "🕒 TIMESTAMP: $formattedTime IST",
                                fontSize = 10.sp,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "💨 WIND: ${telemetry.windSpeed.toInt()} km/h | 🌧️ RAIN PROB: ${telemetry.rainProbability}% | 🌡️ TEMP: ${telemetry.temperature.toInt()}°C",
                                fontSize = 9.sp,
                                color = Color(0xFF34D399),
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "🏛️ PMFBY SEC 72-HR CROP LOSS EVIDENCE VERIFIED",
                                fontSize = 9.sp,
                                color = GoldWheat,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Submit Button
                Button(
                    onClick = {
                        onSubmit(farmerName, mobileNumber, selectedCrop, selectedCause)
                    },
                    modifier = Modifier
                        .testTag("submit_pmfby_claim_button")
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AgriMintAccent,
                        contentColor = AgriDarkForest
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Verified,
                        contentDescription = "Submit Claim",
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = when (language) {
                            Language.HINDI -> "वाटरमार्क क्लेम दर्ज करें"
                            Language.GUJARATI -> "વોટરમાર્ક ક્લેમ નોંધાવો"
                            Language.ENGLISH -> "Submit Watermarked Claim"
                        },
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun PmfbyReceiptDialog(
    claim: PmfbyClaim,
    language: Language,
    onDismiss: () -> Unit
) {
    val formattedDate = remember(claim.timestamp) {
        val sdf = SimpleDateFormat("dd MMMM yyyy, hh:mm a", Locale.ENGLISH)
        sdf.format(Date(claim.timestamp))
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .testTag("pmfby_claim_receipt_dialog")
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .border(2.dp, SafeEmerald, RoundedCornerShape(24.dp)),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF04180E)),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Success Badge
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(SafeEmerald),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Claim Submitted",
                        tint = Color.White,
                        modifier = Modifier.size(32.dp)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = when (language) {
                        Language.HINDI -> "फसल क्षति क्लेम रसीद"
                        Language.GUJARATI -> "પાક નુકસાન ક્લેમ રસીદ"
                        Language.ENGLISH -> "PMFBY Loss Claim Receipt"
                    },
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        fontSize = 20.sp
                    )
                )

                // Reference ID Card
                Surface(
                    color = Color.Black.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldWheat),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "CLAIM REFERENCE ID",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.LightGray
                        )
                        Text(
                            text = claim.claimId,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            color = GoldWheat,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Details table
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0D2818), RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    ReceiptRow(label = "Farmer:", value = claim.farmerName)
                    ReceiptRow(label = "Mobile:", value = claim.mobileNumber)
                    ReceiptRow(label = "District:", value = claim.districtName)
                    ReceiptRow(label = "Crop Type:", value = claim.cropName)
                    ReceiptRow(label = "Cause:", value = claim.damageCause)
                    ReceiptRow(label = "Time:", value = formattedDate)
                    ReceiptRow(
                        label = "Telemetry:",
                        value = "Wind ${claim.windSpeedKmH.toInt()}km/h | Rain ${claim.rainProbPct}% | ${claim.tempC.toInt()}°C",
                        valueColor = Color(0xFF34D399)
                    )
                    ReceiptRow(
                        label = "GPS Watermark:",
                        value = "Lat ${claim.latitude}, Lon ${claim.longitude}",
                        valueColor = Color.Yellow
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Actions: Share / Done
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier
                            .testTag("dismiss_claim_receipt_button")
                            .weight(1f)
                            .height(48.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AgriMintAccent,
                            contentColor = AgriDarkForest
                        )
                    ) {
                        Text(
                            text = "Done / बंद करें",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ReceiptRow(
    label: String,
    value: String,
    valueColor: Color = Color.White
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = Color(0xFF94A3B8),
            fontWeight = FontWeight.SemiBold
        )
        Text(
            text = value,
            fontSize = 12.sp,
            color = valueColor,
            fontWeight = FontWeight.Bold
        )
    }
}
