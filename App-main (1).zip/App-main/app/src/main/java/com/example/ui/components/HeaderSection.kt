package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.District
import com.example.data.Language
import com.example.ui.theme.AgriDarkForest
import com.example.ui.theme.AgriDeepGreen
import com.example.ui.theme.AgriLeafGreen
import com.example.ui.theme.AgriMintAccent
import com.example.ui.theme.AgriPaleGreen
import com.example.ui.theme.GoldWheat

@Composable
fun HeaderSection(
    currentDistrict: District,
    currentLanguage: Language,
    audioEnabled: Boolean,
    isLoading: Boolean,
    onDistrictClick: () -> Unit,
    onLanguageChange: (Language) -> Unit,
    onAudioToggle: () -> Unit,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = AgriDarkForest,
        modifier = modifier.fillMaxWidth(),
        tonalElevation = 6.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Row 1: Logo & Sound Toggle & Refresh
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(AgriMintAccent),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.WbSunny,
                            contentDescription = "WeatherGPT Logo",
                            tint = AgriDarkForest,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "WeatherGPT",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Black,
                                fontSize = 22.sp,
                                color = Color.White
                            )
                        )
                        Text(
                            text = when (currentLanguage) {
                                Language.HINDI -> "किसान कृषि निर्णय इंजन"
                                Language.GUJARATI -> "કિસાન કૃષિ નિર્ણય એન્જિન"
                                Language.ENGLISH -> "Kisan Agri Decision Engine"
                            },
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontSize = 11.sp,
                                color = AgriMintAccent,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Audio toggle button
                    IconButton(
                        onClick = onAudioToggle,
                        modifier = Modifier
                            .testTag("audio_toggle_button")
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(if (audioEnabled) AgriDeepGreen else Color.DarkGray)
                    ) {
                        Icon(
                            imageVector = if (audioEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeMute,
                            contentDescription = if (audioEnabled) "Voice Feedback On" else "Voice Feedback Muted",
                            tint = if (audioEnabled) GoldWheat else Color.LightGray,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Refresh button
                    IconButton(
                        onClick = onRefresh,
                        modifier = Modifier
                            .testTag("refresh_weather_button")
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(AgriDeepGreen)
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = AgriMintAccent,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Refresh Live Telemetry",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Row 2: Active District Pill & Language Switcher
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // District selector button
                Row(
                    modifier = Modifier
                        .testTag("district_selector_chip")
                        .clip(RoundedCornerShape(20.dp))
                        .background(AgriDeepGreen)
                        .border(1.dp, AgriLeafGreen, RoundedCornerShape(20.dp))
                        .clickable(onClick = onDistrictClick)
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = "District Location",
                        tint = GoldWheat,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${currentDistrict.localizedName(currentLanguage)}, ${currentDistrict.state}",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 13.sp
                        )
                    )
                }

                // Language pills
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0xFF040D0A))
                        .padding(2.dp)
                ) {
                    Language.values().forEach { lang ->
                        val isSelected = lang == currentLanguage
                        Box(
                            modifier = Modifier
                                .testTag("lang_chip_${lang.code}")
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (isSelected) AgriMintAccent else Color.Transparent)
                                .clickable { onLanguageChange(lang) }
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = lang.nativeName,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = if (isSelected) FontWeight.Black else FontWeight.Normal,
                                    color = if (isSelected) AgriDarkForest else Color.LightGray,
                                    fontSize = 12.sp
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}
