package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AgriDecision
import com.example.data.AlertSeverity
import com.example.data.District
import com.example.data.Language
import com.example.data.PRESET_DISTRICTS
import com.example.data.PmfbyClaim
import com.example.data.WeatherTelemetry
import com.example.logic.AgriDecisionEngine
import com.example.service.OpenMeteoRepository
import com.example.service.VoiceEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

enum class SimulationMode {
    LIVE,
    CALM,
    GALE,
    HEAVY_RAIN,
    STORM
}

class WeatherGptViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = OpenMeteoRepository()

    private val _language = MutableStateFlow(Language.ENGLISH)
    val language: StateFlow<Language> = _language.asStateFlow()

    private val _selectedDistrict = MutableStateFlow(PRESET_DISTRICTS[0]) // Surat default
    val selectedDistrict: StateFlow<District> = _selectedDistrict.asStateFlow()

    private val _telemetry = MutableStateFlow(
        repository.getFallbackTelemetry(PRESET_DISTRICTS[0])
    )
    val telemetry: StateFlow<WeatherTelemetry> = _telemetry.asStateFlow()

    private val _decision = MutableStateFlow(
        AgriDecisionEngine.evaluate(_telemetry.value, _language.value)
    )
    val decision: StateFlow<AgriDecision> = _decision.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _audioFeedbackEnabled = MutableStateFlow(true)
    val audioFeedbackEnabled: StateFlow<Boolean> = _audioFeedbackEnabled.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _currentTranscript = MutableStateFlow<String?>(null)
    val currentTranscript: StateFlow<String?> = _currentTranscript.asStateFlow()

    private val _voiceResponse = MutableStateFlow<String?>(null)
    val voiceResponse: StateFlow<String?> = _voiceResponse.asStateFlow()

    private val _showDistrictDialog = MutableStateFlow(false)
    val showDistrictDialog: StateFlow<Boolean> = _showDistrictDialog.asStateFlow()

    private val _showPmfbyDialog = MutableStateFlow(false)
    val showPmfbyDialog: StateFlow<Boolean> = _showPmfbyDialog.asStateFlow()

    private val _lastClaimReceipt = MutableStateFlow<PmfbyClaim?>(null)
    val lastClaimReceipt: StateFlow<PmfbyClaim?> = _lastClaimReceipt.asStateFlow()

    private val _simulationMode = MutableStateFlow(SimulationMode.LIVE)
    val simulationMode: StateFlow<SimulationMode> = _simulationMode.asStateFlow()

    private val _snackBarMessage = MutableStateFlow<String?>(null)
    val snackBarMessage: StateFlow<String?> = _snackBarMessage.asStateFlow()

    private var voiceEngine: VoiceEngine? = null

    init {
        initVoiceEngine()
        fetchLiveWeather()
    }

    private fun initVoiceEngine() {
        voiceEngine = VoiceEngine(
            context = getApplication(),
            onTranscript = { text ->
                _currentTranscript.value = text
                handleFarmerQuery(text)
            },
            onListeningStateChanged = { listening ->
                _isListening.value = listening
            },
            onSpeakingStateChanged = { speaking ->
                _isSpeaking.value = speaking
            },
            onError = { msg ->
                _snackBarMessage.value = msg
            }
        )
    }

    fun setLanguage(lang: Language) {
        _language.value = lang
        _decision.value = AgriDecisionEngine.evaluate(_telemetry.value, lang)
        if (_voiceResponse.value != null) {
            _voiceResponse.value = _decision.value.fullVoiceScript
        }
    }

    fun setDistrict(district: District) {
        _selectedDistrict.value = district
        _showDistrictDialog.value = false
        if (_simulationMode.value == SimulationMode.LIVE) {
            fetchLiveWeather()
        } else {
            // reapply simulation with new district coordinates
            reapplySimulation(_simulationMode.value)
        }
    }

    fun toggleAudioFeedback() {
        val next = !_audioFeedbackEnabled.value
        _audioFeedbackEnabled.value = next
        if (!next) {
            stopAudio()
        }
    }

    fun fetchLiveWeather() {
        _isLoading.value = true
        _simulationMode.value = SimulationMode.LIVE
        viewModelScope.launch {
            val result = repository.fetchWeather(_selectedDistrict.value)
            result.onSuccess { data ->
                _telemetry.value = data
                _decision.value = AgriDecisionEngine.evaluate(data, _language.value)
            }
            _isLoading.value = false
        }
    }

    fun applySimulation(mode: SimulationMode) {
        _simulationMode.value = mode
        reapplySimulation(mode)
    }

    private fun reapplySimulation(mode: SimulationMode) {
        val district = _selectedDistrict.value
        val data = when (mode) {
            SimulationMode.LIVE -> {
                fetchLiveWeather()
                return
            }
            SimulationMode.CALM -> repository.getCalmSimulation(district)
            SimulationMode.GALE -> repository.getGaleSimulation(district)
            SimulationMode.HEAVY_RAIN -> repository.getHeavyRainSimulation(district)
            SimulationMode.STORM -> repository.getStormSimulation(district)
        }
        _telemetry.value = data
        _decision.value = AgriDecisionEngine.evaluate(data, _language.value)
        _snackBarMessage.value = "Loaded: ${data.simulationLabel}"
    }

    fun startListening() {
        voiceEngine?.startListening(_language.value)
    }

    fun stopListening() {
        voiceEngine?.stopListening()
    }

    fun stopAudio() {
        voiceEngine?.stopSpeaking()
        _isSpeaking.value = false
    }

    fun speakCurrentVerdict() {
        val textToSpeak = _decision.value.fullVoiceScript
        _voiceResponse.value = textToSpeak
        if (_audioFeedbackEnabled.value) {
            voiceEngine?.speak(textToSpeak, _language.value)
        }
    }

    fun handleFarmerQuery(query: String) {
        _currentTranscript.value = query
        val normalized = query.lowercase()
        val lang = _language.value
        val tel = _telemetry.value
        val dec = _decision.value

        val response = when {
            // Spraying inquiries
            normalized.contains("spray") || normalized.contains("छिड़काव") || normalized.contains("छંટકાવ") ||
            normalized.contains("fertilizer") || normalized.contains("खाद") || normalized.contains("દવા") -> {
                when (lang) {
                    Language.HINDI -> if (dec.severity == AlertSeverity.SAFE) {
                        "हां, आप आज छिड़काव कर सकते हैं। हवा ${tel.windSpeed.toInt()} किमी/घंटा है और बारिश का खतरा केवल ${tel.rainProbability}% है।"
                    } else {
                        "बिल्कुल नहीं! आज छिड़काव न करें। तेज हवा (${tel.windSpeed.toInt()} किमी/घंटा) या बारिश से दवा धुल जाएगी।"
                    }
                    Language.GUJARATI -> if (dec.severity == AlertSeverity.SAFE) {
                        "હા, આજે દવાનો છંટકાવ કરી શકાય છે. પવન શાંત છે અને વરસાદનું જોખમ માત્ર ${tel.rainProbability}% છે."
                    } else {
                        "ના, આજે છંટકાવ કરશો નહીં! પવન ${tel.windSpeed.toInt()} કિમી/કલાક છે અને વરસાદની શક્યતાથી દવા ધોવાઈ જશે."
                    }
                    Language.ENGLISH -> if (dec.severity == AlertSeverity.SAFE) {
                        "Yes, safe to spray today! Wind is calm at ${tel.windSpeed.toInt()} km/h and rain probability is ${tel.rainProbability}%."
                    } else {
                        "Do NOT spray today! Wind is ${tel.windSpeed.toInt()} km/h and rain probability is ${tel.rainProbability}%. Postponing saves your input budget."
                    }
                }
            }

            // Storm inquiries
            normalized.contains("storm") || normalized.contains("आंधी") || normalized.contains("तूफान") ||
            normalized.contains("વાવાઝોડું") || normalized.contains("તોફાન") || normalized.contains("wind") || normalized.contains("हवा") -> {
                when (lang) {
                    Language.HINDI -> if (tel.windSpeed > 45.0) {
                        "सावधान! भयंकर तूफान का अलर्ट है! हवा ${tel.windSpeed.toInt()} किमी/घंटा है। तुरंत खेत से बाहर निकलें।"
                    } else if (tel.windSpeed > 20.0) {
                        "हवा मध्यम से तेज गति (${tel.windSpeed.toInt()} किमी/घंटा) से चल रही है। सतर्क रहें।"
                    } else {
                        "तूफान का कोई खतरा नहीं है। हवा सामान्य गति (${tel.windSpeed.toInt()} किमी/घंटा) पर चल रही है।"
                    }
                    Language.GUJARATI -> if (tel.windSpeed > 45.0) {
                        "સાવધાન! ભારે વાવાઝોડાનું જોખમ છે. પવનની ગતિ ${tel.windSpeed.toInt()} કિમી/કલાક છે. ખેતરમાંથી તાત્કાલિક બહાર આવો."
                    } else if (tel.windSpeed > 20.0) {
                        "પવનની ગતિ સામાન્ય કરતાં વધુ (${tel.windSpeed.toInt()} કિમી/કલાક) છે. સાવચેતી રાખો."
                    } else {
                        "વાવાઝોડાનું કોઈ જોખમ નથી. પવન શાંત છે (${tel.windSpeed.toInt()} કિમી/કલાક)."
                    }
                    Language.ENGLISH -> if (tel.windSpeed > 45.0) {
                        "Extreme Danger! Convective Storm Alert with winds reaching ${tel.windSpeed.toInt()} km/h. Vacate fields immediately!"
                    } else if (tel.windSpeed > 20.0) {
                        "Moderate breezy conditions at ${tel.windSpeed.toInt()} km/h. Keep field implements secured."
                    } else {
                        "No storm risk. Wind speeds are calm at ${tel.windSpeed.toInt()} km/h."
                    }
                }
            }

            // Harvest inquiries
            normalized.contains("harvest") || normalized.contains("कटाई") || normalized.contains("લણણી") ||
            normalized.contains("crop") || normalized.contains("फसल") || normalized.contains("પાક") -> {
                when (lang) {
                    Language.HINDI -> if (tel.rainProbability > 70 || tel.windSpeed > 40.0) {
                        "फसल कटाई तुरंत करें! अगले 6 से 12 घंटे में तेज बारिश (${tel.rainProbability}%) से फसल गिर सकती है।"
                    } else {
                        "फसल कटाई के लिए मौसम अनुकूल है। कोई तात्कालिक बारिश का खतरा नहीं है।"
                    }
                    Language.GUJARATI -> if (tel.rainProbability > 70 || tel.windSpeed > 40.0) {
                        "પાક લણણી તાત્કાલિક પૂર્ણ કરો! આગામી 6 થી 12 કલાકમાં ભારે વરસાદ (${tel.rainProbability}%) નું જોખમ છે."
                    } else {
                        "પાક લણણી માટે વાતાવરણ સારું છે. કોઈ અણધાર્યો વરસાદ નથી."
                    }
                    Language.ENGLISH -> if (tel.rainProbability > 70 || tel.windSpeed > 40.0) {
                        "Urgent harvest recommended! Rain probability is ${tel.rainProbability}%. Harvest within 6-12 hours."
                    } else {
                        "Harvest conditions are stable. No urgent weather hazards detected."
                    }
                }
            }

            // PMFBY Crop insurance inquiries
            normalized.contains("insurance") || normalized.contains("बीमा") || normalized.contains("વીમા") ||
            normalized.contains("pmfby") || normalized.contains("damage") || normalized.contains("नुकसान") || normalized.contains("નુકસાન") -> {
                when (lang) {
                    Language.HINDI -> "प्रधानमंत्री फसल बीमा योजना (PMFBY) के तहत नुकसान का क्लेम करने के लिए नीचे दिए गए 'फसल क्षति दर्ज करें' बटन पर टैप करें।"
                    Language.GUJARATI -> "પ્રધાનમંત્રી પાક વીમા યોજના (PMFBY) હેઠળ વળતર મેળવવા માટે નીચેના 'પાક નુકસાન નોંધાવો' બટન પર ટેપ કરો."
                    Language.ENGLISH -> "Under PMFBY, you can submit geotagged damage evidence within 72 hours. Tap 'Report Crop Damage (PMFBY)' below."
                }
            }

            // Default fallback response based on full decision
            else -> dec.fullVoiceScript
        }

        _voiceResponse.value = response
        if (_audioFeedbackEnabled.value) {
            voiceEngine?.speak(response, lang)
        }
    }

    fun submitPmfbyClaim(
        farmerName: String,
        mobileNumber: String,
        cropName: String,
        damageCause: String
    ) {
        val tel = _telemetry.value
        val claim = PmfbyClaim(
            claimId = "PMFBY-${UUID.randomUUID().toString().take(8).uppercase()}",
            farmerName = farmerName.ifBlank { "Kisan Farmer" },
            mobileNumber = mobileNumber.ifBlank { "9876543210" },
            cropName = cropName.ifBlank { "Cotton" },
            damageCause = damageCause.ifBlank { "Heavy Rain / Inundation" },
            districtName = tel.district.localizedName(_language.value),
            latitude = tel.district.lat,
            longitude = tel.district.lon,
            timestamp = System.currentTimeMillis(),
            windSpeedKmH = tel.windSpeed,
            rainProbPct = tel.rainProbability,
            tempC = tel.temperature,
            photoCaptured = true
        )
        _lastClaimReceipt.value = claim
        _showPmfbyDialog.value = false

        val confirmationMsg = when (_language.value) {
            Language.HINDI -> "फसल क्षति क्लेम #${claim.claimId} सफलता से दर्ज हो गया है।"
            Language.GUJARATI -> "પાક નુકસાન ક્લેમ #${claim.claimId} સફળતાપૂર્વક નોંધાયો છે."
            Language.ENGLISH -> "PMFBY Claim #${claim.claimId} generated successfully with telemetry watermark!"
        }
        _snackBarMessage.value = confirmationMsg
        if (_audioFeedbackEnabled.value) {
            voiceEngine?.speak(confirmationMsg, _language.value)
        }
    }

    fun openPmfbyDialog() {
        _showPmfbyDialog.value = true
    }

    fun closePmfbyDialog() {
        _showPmfbyDialog.value = false
    }

    fun openDistrictDialog() {
        _showDistrictDialog.value = true
    }

    fun closeDistrictDialog() {
        _showDistrictDialog.value = false
    }

    fun dismissClaimReceipt() {
        _lastClaimReceipt.value = null
    }

    fun clearSnackBar() {
        _snackBarMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        voiceEngine?.release()
    }
}
