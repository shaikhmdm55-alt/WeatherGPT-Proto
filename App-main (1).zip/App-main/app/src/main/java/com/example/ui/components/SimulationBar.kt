package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Language
import com.example.ui.SimulationMode
import com.example.ui.theme.AgriDarkForest
import com.example.ui.theme.AgriMintAccent
import com.example.ui.theme.GoldWheat
import com.example.ui.theme.HazardRed
import com.example.ui.theme.SafeEmerald
import com.example.ui.theme.WarningAmber

@Composable
fun SimulationBar(
    currentMode: SimulationMode,
    language: Language,
    onSelectMode: (SimulationMode) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Color(0xFF06140C),
        modifier = modifier.fillMaxWidth(),
        tonalElevation = 4.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = when (language) {
                        Language.HINDI -> "🧪 टेस्ट सिम्युलेटर (Edge Cases):"
                        Language.GUJARATI -> "🧪 સિમ્યુલેટર (Edge Cases):"
                        Language.ENGLISH -> "🧪 Demo Simulation Bar (Test Rules):"
                    },
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = Color(0xFF94A3B8),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                )

                if (currentMode != SimulationMode.LIVE) {
                    Text(
                        text = "SIMULATED",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = GoldWheat,
                            fontWeight = FontWeight.Black,
                            fontSize = 10.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Live Open-Meteo
                SimPill(
                    label = "📡 Live Open-Meteo",
                    isSelected = currentMode == SimulationMode.LIVE,
                    activeColor = AgriMintAccent,
                    testTag = "sim_live",
                    onClick = { onSelectMode(SimulationMode.LIVE) }
                )

                // Calm
                SimPill(
                    label = "🌿 Simulate Calm",
                    isSelected = currentMode == SimulationMode.CALM,
                    activeColor = SafeEmerald,
                    testTag = "sim_calm",
                    onClick = { onSelectMode(SimulationMode.CALM) }
                )

                // Gale 25 km/h
                SimPill(
                    label = "💨 Simulate Gale (26km/h)",
                    isSelected = currentMode == SimulationMode.GALE,
                    activeColor = WarningAmber,
                    testTag = "sim_gale",
                    onClick = { onSelectMode(SimulationMode.GALE) }
                )

                // Heavy Rain 80%
                SimPill(
                    label = "🌧️ Simulate Heavy Rain (82%)",
                    isSelected = currentMode == SimulationMode.HEAVY_RAIN,
                    activeColor = WarningAmber,
                    testTag = "sim_heavy_rain",
                    onClick = { onSelectMode(SimulationMode.HEAVY_RAIN) }
                )

                // Squall / Storm 48 km/h
                SimPill(
                    label = "⚡ Simulate Storm (52km/h)",
                    isSelected = currentMode == SimulationMode.STORM,
                    activeColor = HazardRed,
                    testTag = "sim_storm",
                    onClick = { onSelectMode(SimulationMode.STORM) }
                )
            }
        }
    }
}

@Composable
private fun SimPill(
    label: String,
    isSelected: Boolean,
    activeColor: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .testTag(testTag)
            .clip(RoundedCornerShape(16.dp))
            .background(if (isSelected) activeColor else Color(0xFF0F2D1C))
            .border(1.dp, if (isSelected) Color.White else Color(0xFF265A3B), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = if (isSelected) FontWeight.Black else FontWeight.SemiBold,
            color = if (isSelected) AgriDarkForest else Color.White
        )
    }
}
