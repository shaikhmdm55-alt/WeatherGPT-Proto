package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme =
  darkColorScheme(
    primary = AgriMintAccent,
    onPrimary = AgriDarkForest,
    primaryContainer = AgriDeepGreen,
    onPrimaryContainer = AgriPaleGreen,
    secondary = GoldWheat,
    onSecondary = AgriDarkForest,
    background = SurfaceDark,
    onBackground = TextPrimaryLight,
    surface = SurfaceCardDark,
    onSurface = TextPrimaryLight,
    surfaceVariant = AgriDeepGreen,
    onSurfaceVariant = AgriPaleGreen,
    error = HazardRed,
    onError = Color.White
  )

private val LightColorScheme =
  lightColorScheme(
    primary = AgriDeepGreen,
    onPrimary = Color.White,
    primaryContainer = AgriPaleGreen,
    onPrimaryContainer = AgriDarkForest,
    secondary = AgriLeafGreen,
    onSecondary = Color.White,
    background = Color(0xFFF1F5F2),
    onBackground = TextPrimaryDark,
    surface = CardLightBg,
    onSurface = TextPrimaryDark,
    surfaceVariant = Color(0xFFE2EBE5),
    onSurfaceVariant = AgriDarkForest,
    error = HazardRed,
    onError = Color.White
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Keep intentional agricultural theme
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}

