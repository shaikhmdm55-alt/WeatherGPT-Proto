package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Language
import com.example.ui.theme.AgriDarkForest
import com.example.ui.theme.AgriDeepGreen
import com.example.ui.theme.AgriLeafGreen
import com.example.ui.theme.AgriMintAccent
import com.example.ui.theme.AgriPaleGreen
import com.example.ui.theme.GoldWheat
import com.example.ui.theme.HazardRed
import com.example.ui.theme.SurfaceCardDark

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VoiceInterfaceSection(
    isListening: Boolean,
    isSpeaking: Boolean,
    transcript: String?,
    voiceResponse: String?,
    language: Language,
    onMicClick: () -> Unit,
    onQuerySubmit: (String) -> Unit,
    onReplayAudio: () -> Unit,
    modifier: Modifier = Modifier
) {
    var customQueryText by remember { mutableStateOf("") }

    // Pulsing animation for the big microphone when active or waiting
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (isListening) 1.25f else 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isListening) 600 else 1400),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.5.dp, AgriLeafGreen, RoundedCornerShape(24.dp)),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCardDark),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Title & Voice Guidance Banner
            Text(
                text = when (language) {
                    Language.HINDI -> "🎙️ बोलकर पूछें (Voice Assistant)"
                    Language.GUJARATI -> "🎙️ બોલીને પૂછો (Voice Assistant)"
                    Language.ENGLISH -> "🎙️ Voice-First Agri Assistant"
                },
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    fontSize = 18.sp
                )
            )

            Text(
                text = when (language) {
                    Language.HINDI -> "माइक दबाकर अपनी भाषा में सवाल पूछें या नीचे विकल्प चुनें"
                    Language.GUJARATI -> "માઈક દબાવીને પ્રશ્ન પૂછો અથવા નીચેના વિકલ્પ પર ટૅપ કરો"
                    Language.ENGLISH -> "Tap mic and speak your question, or tap quick preset chips below"
                },
                style = MaterialTheme.typography.bodySmall.copy(
                    color = AgriPaleGreen,
                    fontSize = 12.sp
                ),
                modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
            )

            // Central Pulsing Microphone Button
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(110.dp)
                    .padding(8.dp)
            ) {
                // Pulse Ring
                Box(
                    modifier = Modifier
                        .size(90.dp)
                        .scale(pulseScale)
                        .clip(CircleShape)
                        .background(
                            if (isListening) HazardRed.copy(alpha = 0.35f)
                            else AgriMintAccent.copy(alpha = 0.25f)
                        )
                )

                // Actual Button
                Surface(
                    onClick = onMicClick,
                    modifier = Modifier
                        .testTag("central_mic_button")
                        .size(76.dp),
                    shape = CircleShape,
                    color = if (isListening) HazardRed else AgriMintAccent,
                    shadowElevation = 8.dp
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.size(76.dp)
                    ) {
                        Icon(
                            imageVector = if (isListening) Icons.Default.Stop else Icons.Default.Mic,
                            contentDescription = if (isListening) "Stop Listening" else "Start Voice Input",
                            tint = AgriDarkForest,
                            modifier = Modifier.size(38.dp)
                        )
                    }
                }
            }

            // Listening / Speaking Status Indicator
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = when {
                    isListening -> when (language) {
                        Language.HINDI -> "सुन रहा हूँ... बोलिए (Listening...)"
                        Language.GUJARATI -> "સાંભળી રહ્યો છું... બોલો (Listening...)"
                        Language.ENGLISH -> "Listening to your voice..."
                    }
                    isSpeaking -> when (language) {
                        Language.HINDI -> "उत्तर बोल रहा हूँ... (Speaking...)"
                        Language.GUJARATI -> "જવાબ આપી રહ્યો છું... (Speaking...)"
                        Language.ENGLISH -> "Speaking response..."
                    }
                    else -> when (language) {
                        Language.HINDI -> "माइक दबाकर बोलें"
                        Language.GUJARATI -> "બોલવા માટે માઈક દબાવો"
                        Language.ENGLISH -> "Tap Mic to Speak"
                    }
                },
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = if (isListening) HazardRed else if (isSpeaking) GoldWheat else AgriMintAccent,
                    fontSize = 14.sp
                )
            )

            // Transcribed query bubble (if farmer spoke)
            if (!transcript.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(14.dp))
                Surface(
                    color = Color.Black.copy(alpha = 0.4f),
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, AgriLeafGreen),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = when (language) {
                                Language.HINDI -> "आपने पूछा:"
                                Language.GUJARATI -> "તમે પૂછ્યું:"
                                Language.ENGLISH -> "You asked:"
                            },
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = GoldWheat,
                                fontSize = 11.sp
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "\"$transcript\"",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White,
                                fontSize = 15.sp
                            )
                        )
                    }
                }
            }

            // Voice response card
            if (!voiceResponse.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    color = AgriDeepGreen,
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, AgriMintAccent),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = when (language) {
                                    Language.HINDI -> "कृषि निर्णय सलाह:"
                                    Language.GUJARATI -> "કૃષિ નિર્ણય સલાહ:"
                                    Language.ENGLISH -> "WeatherGPT Agri Guidance:"
                                },
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = AgriMintAccent,
                                    fontSize = 12.sp
                                )
                            )

                            IconButton(
                                onClick = onReplayAudio,
                                modifier = Modifier
                                    .testTag("replay_voice_button")
                                    .size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VolumeUp,
                                    contentDescription = "Replay Audio Response",
                                    tint = GoldWheat,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = voiceResponse,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = Color.White,
                                fontSize = 15.sp,
                                lineHeight = 21.sp,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                }
            }

            // Quick Preset Question Chips (1-tap access for elderly farmers)
            Spacer(modifier = Modifier.height(18.dp))
            Text(
                text = when (language) {
                    Language.HINDI -> "तुरंत पूछने के लिए टैप करें (Quick Presets):"
                    Language.GUJARATI -> "ઝડપી પ્રશ્નો માટે ટૅપ કરો (Quick Presets):"
                    Language.ENGLISH -> "Tap quick question presets:"
                },
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFCBD5E1),
                    fontSize = 12.sp
                ),
                modifier = Modifier.align(Alignment.Start)
            )

            Spacer(modifier = Modifier.height(8.dp))

            val presets = when (language) {
                Language.HINDI -> listOf(
                    "क्या आज छिड़काव कर सकते हैं? 💧",
                    "आंधी-तूफान का खतरा? ⚡",
                    "फसल कटाई सलाह 🌾",
                    "फसल बीमा सहायता (PMFBY) 📋"
                )
                Language.GUJARATI -> listOf(
                    "શું આજે છંટકાવ કરી શકાય? 💧",
                    "વાવાઝોડાનું જોખમ? ⚡",
                    "પાક લણણી સલાહ 🌾",
                    "પાક વીમા સહાય (PMFBY) 📋"
                )
                Language.ENGLISH -> listOf(
                    "Can I spray today? 💧",
                    "Storm risk? ⚡",
                    "Harvest advice? 🌾",
                    "PMFBY insurance help? 📋"
                )
            }

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                presets.forEachIndexed { index, preset ->
                    Box(
                        modifier = Modifier
                            .testTag("preset_chip_$index")
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0xFF163E27))
                            .border(1.dp, AgriLeafGreen, RoundedCornerShape(20.dp))
                            .clickable { onQuerySubmit(preset) }
                            .padding(horizontal = 14.dp, vertical = 9.dp)
                    ) {
                        Text(
                            text = preset,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White,
                                fontSize = 13.sp
                            )
                        )
                    }
                }
            }

            // Fallback manual question input
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = customQueryText,
                    onValueChange = { customQueryText = it },
                    placeholder = {
                        Text(
                            text = when (language) {
                                Language.HINDI -> "या सवाल यहां टाइप करें..."
                                Language.GUJARATI -> "અથવા પ્રશ્ન અહીં લખો..."
                                Language.ENGLISH -> "Or type question here..."
                            },
                            color = Color.Gray,
                            fontSize = 13.sp
                        )
                    },
                    modifier = Modifier
                        .testTag("voice_text_input")
                        .weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AgriMintAccent,
                        unfocusedBorderColor = AgriLeafGreen,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF040D0A),
                        unfocusedContainerColor = Color(0xFF040D0A)
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = {
                        if (customQueryText.isNotBlank()) {
                            onQuerySubmit(customQueryText)
                            customQueryText = ""
                        }
                    },
                    modifier = Modifier
                        .testTag("send_query_button")
                        .size(48.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(AgriMintAccent)
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Submit Query",
                        tint = AgriDarkForest,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }
}
