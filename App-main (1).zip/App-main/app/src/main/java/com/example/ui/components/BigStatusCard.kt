package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AgriDecision
import com.example.data.AlertSeverity
import com.example.data.Language
import com.example.ui.theme.HazardRed
import com.example.ui.theme.HazardRedDark
import com.example.ui.theme.SafeEmerald
import com.example.ui.theme.SafeEmeraldDark
import com.example.ui.theme.WarningAmber
import com.example.ui.theme.WarningAmberDark

@Composable
fun BigStatusCard(
    decision: AgriDecision,
    isSpeaking: Boolean,
    language: Language,
    onSpeakClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Dynamic background colors according to safety severity
    val (cardGradient, borderColor, headerColor) = when (decision.severity) {
        AlertSeverity.SAFE -> Triple(
            Brush.verticalGradient(listOf(SafeEmeraldDark, Color(0xFF032B1C))),
            SafeEmerald,
            Color(0xFF34D399)
        )
        AlertSeverity.SPRAY_MORATORIUM -> Triple(
            Brush.verticalGradient(listOf(HazardRedDark, Color(0xFF3B0B0B))),
            HazardRed,
            Color(0xFFF87171)
        )
        AlertSeverity.URGENT_HARVEST -> Triple(
            Brush.verticalGradient(listOf(WarningAmberDark, Color(0xFF3E1D04))),
            WarningAmber,
            Color(0xFFFBBF24)
        )
        AlertSeverity.STORM_ALERT -> Triple(
            Brush.verticalGradient(listOf(Color(0xFF881337), Color(0xFF4C0519))),
            Color(0xFFFB7185),
            Color(0xFFFDA4AF)
        )
    }

    Card(
        modifier = modifier
            .testTag("big_status_card")
            .fillMaxWidth()
            .border(2.dp, borderColor, RoundedCornerShape(20.dp)),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(cardGradient)
                .padding(20.dp)
        ) {
            Column {
                // Top row: Status Badge & Speak/Stop Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Status Badge
                    Surface(
                        color = Color.Black.copy(alpha = 0.4f),
                        shape = RoundedCornerShape(24.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, headerColor)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = decision.badgeIcon,
                                fontSize = 18.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = decision.statusTitle,
                                style = MaterialTheme.typography.labelLarge.copy(
                                    fontWeight = FontWeight.Black,
                                    fontSize = 13.sp,
                                    color = headerColor
                                )
                            )
                        }
                    }

                    // Large Listen button
                    Row(
                        modifier = Modifier
                            .testTag("listen_verdict_button")
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (isSpeaking) HazardRed else Color.White)
                            .clickable(onClick = onSpeakClick)
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isSpeaking) Icons.Default.Stop else Icons.Default.PlayArrow,
                            contentDescription = if (isSpeaking) "Stop Audio" else "Listen Aloud",
                            tint = if (isSpeaking) Color.White else Color.Black,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isSpeaking) {
                                when (language) {
                                    Language.HINDI -> "रोकें"
                                    Language.GUJARATI -> "બંધ કરો"
                                    Language.ENGLISH -> "Stop"
                                }
                            } else {
                                when (language) {
                                    Language.HINDI -> "सुनें 🔊"
                                    Language.GUJARATI -> "સાંભળો 🔊"
                                    Language.ENGLISH -> "Listen 🔊"
                                }
                            },
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isSpeaking) Color.White else Color.Black,
                                fontSize = 13.sp
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Giant Verdict Text
                Text(
                    text = decision.verdictSummary,
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.Black,
                        fontSize = 24.sp,
                        lineHeight = 30.sp,
                        color = Color.White
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Actionable Plain-language Sentences
                decision.actionSentences.forEach { sentence ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(
                            text = "•",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = headerColor,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                        Text(
                            text = sentence,
                            style = MaterialTheme.typography.bodyLarge.copy(
                                fontSize = 15.sp,
                                lineHeight = 21.sp,
                                color = Color(0xFFF1F5F9),
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                }

                // Economic Impact / Savings Highlight
                if (!decision.economicBenefit.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Surface(
                        color = Color.Black.copy(alpha = 0.35f),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0).copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "💰",
                                fontSize = 18.sp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = decision.economicBenefit,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFFEF08A),
                                    fontSize = 14.sp
                                )
                            )
                        }
                    }
                }

                // Operational Window Pill
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Text(
                        text = "⏱️ ${decision.operationalWindow}",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFCBD5E1),
                            fontSize = 12.sp
                        )
                    )
                }
            }
        }
    }
}
