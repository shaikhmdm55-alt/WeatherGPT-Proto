package com.example.data

enum class Language(val code: String, val displayName: String, val nativeName: String) {
    ENGLISH("en", "English", "English"),
    HINDI("hi", "Hindi", "हिन्दी"),
    GUJARATI("gu", "Gujarati", "ગુજરાતી")
}

data class District(
    val id: String,
    val nameEn: String,
    val nameHi: String,
    val nameGu: String,
    val state: String,
    val lat: Double,
    val lon: Double
) {
    fun localizedName(lang: Language): String = when (lang) {
        Language.ENGLISH -> nameEn
        Language.HINDI -> nameHi
        Language.GUJARATI -> nameGu
    }
}

val PRESET_DISTRICTS = listOf(
    District("surat", "Surat", "सूरत", "સુરત", "Gujarat", 21.1702, 72.8311),
    District("rajkot", "Rajkot", "राजकोट", "રાજકોટ", "Gujarat", 22.3039, 70.8022),
    District("nagpur", "Nagpur", "नागपुर", "નાગપુર", "Maharashtra", 21.1458, 79.0882),
    District("ludhiana", "Ludhiana", "लुधियाना", "લુધિયાણા", "Punjab", 30.9010, 75.8573),
    District("indore", "Indore", "इंदौर", "ઈન્દોર", "Madhya Pradesh", 22.7196, 75.8577),
    District("nashik", "Nashik", "नासिक", "નાસિક", "Maharashtra", 19.9975, 73.7898),
    District("patna", "Patna", "पटना", "પટના", "Bihar", 25.5941, 85.1376),
    District("belagavi", "Belagavi", "बेलगावी", "બેલગાવી", "Karnataka", 15.8497, 74.4977),
    District("varanasi", "Varanasi", "वाराणसी", "વારાણસી", "Uttar Pradesh", 25.3176, 82.9739),
    District("warangal", "Warangal", "वारंगल", "વારંગલ", "Telangana", 17.9689, 79.5941)
)

data class WeatherTelemetry(
    val temperature: Double,
    val relativeHumidity: Int,
    val windSpeed: Double, // km/h
    val rainProbability: Int, // %
    val weatherCode: Int,
    val district: District,
    val isSimulated: Boolean = false,
    val simulationLabel: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

enum class AlertSeverity {
    SAFE,             // Emerald Green
    SPRAY_MORATORIUM, // Crimson/Red Alert
    URGENT_HARVEST,   // Amber Warning
    STORM_ALERT       // Bright Crimson Flashing Alert
}

data class AgriDecision(
    val severity: AlertSeverity,
    val statusTitle: String,
    val badgeIcon: String,
    val verdictSummary: String,
    val actionSentences: List<String>,
    val economicBenefit: String?,
    val operationalWindow: String,
    val fullVoiceScript: String
)

data class PmfbyClaim(
    val claimId: String,
    val farmerName: String,
    val mobileNumber: String,
    val cropName: String,
    val damageCause: String,
    val districtName: String,
    val latitude: Double,
    val longitude: Double,
    val timestamp: Long,
    val windSpeedKmH: Double,
    val rainProbPct: Int,
    val tempC: Double,
    val photoCaptured: Boolean = true
)
