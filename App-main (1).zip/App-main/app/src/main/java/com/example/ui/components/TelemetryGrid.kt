package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AgriDecision
import com.example.data.AlertSeverity
import com.example.data.Language
import com.example.data.WeatherTelemetry
import com.example.ui.theme.AgriPaleGreen
import com.example.ui.theme.HazardRed
import com.example.ui.theme.SafeEmerald
import com.example.ui.theme.SurfaceCardDark
import com.example.ui.theme.WarningAmber

@Composable
fun TelemetryGrid(
    telemetry: WeatherTelemetry,
    decision: AgriDecision,
    language: Language,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        // Section Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = when (language) {
                    Language.HINDI -> "खेत का मौसम डेटा (Live Telemetry)"
                    Language.GUJARATI -> "ખેતરનું હવામાન (Live Telemetry)"
                    Language.ENGLISH -> "Farm Telemetry (Live)"
                },
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 16.sp
                )
            )

            if (telemetry.isSimulated) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFB45309))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "TEST MODE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(SafeEmerald)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Open-Meteo",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = AgriPaleGreen
                    )
                }
            }
        }

        // Row 1: Wind Speed & Rain Probability
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val isWindHazard = telemetry.windSpeed > 15.0
            val isWindStorm = telemetry.windSpeed > 45.0
            val windBadgeColor = if (isWindStorm) HazardRed else if (isWindHazard) WarningAmber else SafeEmerald

            TelemetryTile(
                modifier = Modifier
                    .weight(1f)
                    .testTag("telemetry_wind_speed"),
                icon = Icons.Default.Air,
                label = when (language) {
                    Language.HINDI -> "हवा की गति"
                    Language.GUJARATI -> "પવનની ઝડપ"
                    Language.ENGLISH -> "Wind Speed"
                },
                value = "${telemetry.windSpeed.toInt()}",
                unit = "km/h",
                statusPill = if (isWindStorm) "Storm (>45)" else if (isWindHazard) "High (>15)" else "Calm (<15)",
                statusColor = windBadgeColor
            )

            val isRainHazard = telemetry.rainProbability > 30
            val isRainSevere = telemetry.rainProbability > 70
            val rainBadgeColor = if (isRainSevere) HazardRed else if (isRainHazard) WarningAmber else SafeEmerald

            TelemetryTile(
                modifier = Modifier
                    .weight(1f)
                    .testTag("telemetry_rain_probability"),
                icon = Icons.Default.WaterDrop,
                label = when (language) {
                    Language.HINDI -> "बारिश की संभावना"
                    Language.GUJARATI -> "વરસાદની શક્યતા"
                    Language.ENGLISH -> "Rain Probability"
                },
                value = "${telemetry.rainProbability}",
                unit = "%",
                statusPill = if (isRainSevere) "Heavy (>70%)" else if (isRainHazard) "Risk (>30%)" else "Low (<30%)",
                statusColor = rainBadgeColor
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Row 2: Temperature & Operational Window
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            TelemetryTile(
                modifier = Modifier
                    .weight(1f)
                    .testTag("telemetry_temperature"),
                icon = Icons.Default.Thermostat,
                label = when (language) {
                    Language.HINDI -> "तापमान"
                    Language.GUJARATI -> "તાપમાન"
                    Language.ENGLISH -> "Temperature"
                },
                value = "${telemetry.temperature.toInt()}",
                unit = "°C",
                statusPill = "Humidity: ${telemetry.relativeHumidity}%",
                statusColor = AgriPaleGreen
            )

            val opColor = when (decision.severity) {
                AlertSeverity.SAFE -> SafeEmerald
                AlertSeverity.SPRAY_MORATORIUM -> WarningAmber
                AlertSeverity.URGENT_HARVEST -> WarningAmber
                AlertSeverity.STORM_ALERT -> HazardRed
            }

            val opWindowLabel = when (decision.severity) {
                AlertSeverity.SAFE -> when (language) {
                    Language.HINDI -> "अगले 6 घंटे सुरक्षित"
                    Language.GUJARATI -> "આગામી 6 કલાક અનુકૂળ"
                    Language.ENGLISH -> "Next 6 Hours Safe"
                }
                AlertSeverity.SPRAY_MORATORIUM -> when (language) {
                    Language.HINDI -> "छिड़काव रोकें"
                    Language.GUJARATI -> "છંટકાવ બંધ"
                    Language.ENGLISH -> "Moratorium Active"
                }
                AlertSeverity.URGENT_HARVEST -> when (language) {
                    Language.HINDI -> "6–12 घंटे में काटें"
                    Language.GUJARATI -> "6-12 કલાકમાં લણો"
                    Language.ENGLISH -> "Reap in 6–12h"
                }
                AlertSeverity.STORM_ALERT -> when (language) {
                    Language.HINDI -> "तुरंत खेत छोड़ें"
                    Language.GUJARATI -> "તાત્કાલિક બહાર આવો"
                    Language.ENGLISH -> "Evacuate Field"
                }
            }

            TelemetryTile(
                modifier = Modifier
                    .weight(1f)
                    .testTag("telemetry_operational_window"),
                icon = Icons.Default.HourglassTop,
                label = when (language) {
                    Language.HINDI -> "कार्य समय (Window)"
                    Language.GUJARATI -> "કાર્ય વિન્ડો (Window)"
                    Language.ENGLISH -> "Operation Window"
                },
                value = opWindowLabel,
                unit = "",
                statusPill = decision.badgeIcon,
                statusColor = opColor,
                isTextValue = true
            )
        }
    }
}

@Composable
fun TelemetryTile(
    icon: ImageVector,
    label: String,
    value: String,
    unit: String,
    statusPill: String,
    statusColor: Color,
    modifier: Modifier = Modifier,
    isTextValue: Boolean = false
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF265A3B), RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCardDark),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Header: Icon + Status Pill
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF1B4332)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = statusColor,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(statusColor.copy(alpha = 0.15f))
                        .border(0.8.dp, statusColor.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = statusPill,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = statusColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Value & Unit
            if (isTextValue) {
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Black,
                        fontSize = 17.sp,
                        lineHeight = 22.sp,
                        color = Color.White
                    )
                )
            } else {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = value,
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.Black,
                            fontSize = 32.sp,
                            color = Color.White
                        )
                    )
                    if (unit.isNotEmpty()) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = unit,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = AgriPaleGreen
                            ),
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Label
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    color = Color(0xFF94A3B8)
                )
            )
        }
    }
}
