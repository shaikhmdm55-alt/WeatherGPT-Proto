package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.Language
import com.example.ui.components.BigStatusCard
import com.example.ui.components.DistrictPickerDialog
import com.example.ui.components.HeaderSection
import com.example.ui.components.PmfbyClaimDialog
import com.example.ui.components.PmfbyReceiptDialog
import com.example.ui.components.SimulationBar
import com.example.ui.components.TelemetryGrid
import com.example.ui.components.VoiceInterfaceSection
import com.example.ui.theme.AgriDarkForest
import com.example.ui.theme.AgriDeepGreen
import com.example.ui.theme.AgriMintAccent
import com.example.ui.theme.GoldWheat
import com.example.ui.theme.SurfaceDark

@Composable
fun WeatherGptApp(
    viewModel: WeatherGptViewModel = viewModel()
) {
    val context = LocalContext.current
    val language by viewModel.language.collectAsState()
    val telemetry by viewModel.telemetry.collectAsState()
    val decision by viewModel.decision.collectAsState()
    val district by viewModel.selectedDistrict.collectAsState()
    val audioEnabled by viewModel.audioFeedbackEnabled.collectAsState()
    val isListening by viewModel.isListening.collectAsState()
    val isSpeaking by viewModel.isSpeaking.collectAsState()
    val transcript by viewModel.currentTranscript.collectAsState()
    val voiceResponse by viewModel.voiceResponse.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val simulationMode by viewModel.simulationMode.collectAsState()
    val showDistrictDialog by viewModel.showDistrictDialog.collectAsState()
    val showPmfbyDialog by viewModel.showPmfbyDialog.collectAsState()
    val lastClaimReceipt by viewModel.lastClaimReceipt.collectAsState()
    val snackbarMsg by viewModel.snackBarMessage.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }

    // Audio recording permission launcher
    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.startListening()
        }
    }

    LaunchedEffect(snackbarMsg) {
        snackbarMsg?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearSnackBar()
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.statusBars),
        containerColor = SurfaceDark,
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState) { data ->
                Snackbar(
                    snackbarData = data,
                    containerColor = AgriDeepGreen,
                    contentColor = Color.White,
                    shape = RoundedCornerShape(12.dp)
                )
            }
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                SimulationBar(
                    currentMode = simulationMode,
                    language = language,
                    onSelectMode = { mode -> viewModel.applySimulation(mode) }
                )
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Bar with District & Language Switcher
            item {
                HeaderSection(
                    currentDistrict = district,
                    currentLanguage = language,
                    audioEnabled = audioEnabled,
                    isLoading = isLoading,
                    onDistrictClick = { viewModel.openDistrictDialog() },
                    onLanguageChange = { viewModel.setLanguage(it) },
                    onAudioToggle = { viewModel.toggleAudioFeedback() },
                    onRefresh = { viewModel.fetchLiveWeather() }
                )
            }

            // Big Dynamic Status Card (Emerald / Crimson / Amber)
            item {
                Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                    BigStatusCard(
                        decision = decision,
                        isSpeaking = isSpeaking,
                        language = language,
                        onSpeakClick = {
                            if (isSpeaking) {
                                viewModel.stopAudio()
                            } else {
                                viewModel.speakCurrentVerdict()
                            }
                        }
                    )
                }
            }

            // PMFBY Crop Damage Report Action Button
            item {
                Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                    Button(
                        onClick = { viewModel.openPmfbyDialog() },
                        modifier = Modifier
                            .testTag("report_pmfby_damage_button")
                            .fillMaxWidth()
                            .height(56.dp),
                        shape = RoundedCornerShape(18.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF1E3A8A), // High contrast indigo/navy blue button
                            contentColor = Color.White
                        ),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = "Camera",
                                tint = GoldWheat,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = when (language) {
                                    Language.HINDI -> "📸 फसल क्षति दर्ज करें (PMFBY)"
                                    Language.GUJARATI -> "📸 પાક નુકસાન નોંધાવો (PMFBY)"
                                    Language.ENGLISH -> "📸 Report Crop Damage (PMFBY)"
                                },
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    fontSize = 16.sp,
                                    color = Color.White
                                )
                            )
                        }
                    }
                }
            }

            // Scannable Telemetry Grid (Wind, Rain, Temp, Operational Window)
            item {
                Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                    TelemetryGrid(
                        telemetry = telemetry,
                        decision = decision,
                        language = language
                    )
                }
            }

            // Voice-First Interaction Card with Central Pulsing Mic
            item {
                Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                    VoiceInterfaceSection(
                        isListening = isListening,
                        isSpeaking = isSpeaking,
                        transcript = transcript,
                        voiceResponse = voiceResponse,
                        language = language,
                        onMicClick = {
                            if (isListening) {
                                viewModel.stopListening()
                            } else {
                                val hasAudioPermission = ContextCompat.checkSelfPermission(
                                    context,
                                    Manifest.permission.RECORD_AUDIO
                                ) == PackageManager.PERMISSION_GRANTED

                                if (hasAudioPermission) {
                                    viewModel.startListening()
                                } else {
                                    audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            }
                        },
                        onQuerySubmit = { query -> viewModel.handleFarmerQuery(query) },
                        onReplayAudio = { viewModel.speakCurrentVerdict() }
                    )
                }
            }
        }
    }

    // PMFBY Damage Form Dialog
    if (showPmfbyDialog) {
        PmfbyClaimDialog(
            telemetry = telemetry,
            language = language,
            onDismiss = { viewModel.closePmfbyDialog() },
            onSubmit = { farmerName, mobile, crop, cause ->
                viewModel.submitPmfbyClaim(farmerName, mobile, crop, cause)
            }
        )
    }

    // Generated PMFBY Claim Receipt Dialog
    lastClaimReceipt?.let { claim ->
        PmfbyReceiptDialog(
            claim = claim,
            language = language,
            onDismiss = { viewModel.dismissClaimReceipt() }
        )
    }

    // District Picker Dialog
    if (showDistrictDialog) {
        DistrictPickerDialog(
            currentDistrict = district,
            language = language,
            onDistrictSelected = { newDistrict ->
                viewModel.setDistrict(newDistrict)
            },
            onDismiss = { viewModel.closeDistrictDialog() }
        )
    }
}
