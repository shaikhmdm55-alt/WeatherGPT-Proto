package com.example.service

import android.util.Log
import com.example.data.District
import com.example.data.WeatherTelemetry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class OpenMeteoRepository {

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    suspend fun fetchWeather(district: District): Result<WeatherTelemetry> = withContext(Dispatchers.IO) {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=${district.lat}&longitude=${district.lon}&current=temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m,weather_code&hourly=precipitation_probability,wind_speed_10m&forecast_days=1"
        try {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "WeatherGPT-Kisan/1.0")
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                Log.w("OpenMeteoRepository", "API returned status: ${response.code}")
                return@withContext Result.success(getFallbackTelemetry(district, "Open-Meteo offline, using cached regional data"))
            }

            val responseBody = response.body?.string() ?: return@withContext Result.success(
                getFallbackTelemetry(district, "Empty body, using regional telemetry")
            )

            val json = JSONObject(responseBody)
            val current = json.getJSONObject("current")
            val temp = current.optDouble("temperature_2m", 29.0)
            val wind = current.optDouble("wind_speed_10m", 11.5)
            val humidity = current.optInt("relative_humidity_2m", 62)
            val code = current.optInt("weather_code", 1)

            var rainProb = 10
            if (json.has("hourly")) {
                val hourly = json.getJSONObject("hourly")
                if (hourly.has("precipitation_probability")) {
                    val rainArray = hourly.getJSONArray("precipitation_probability")
                    if (rainArray.length() > 0) {
                        rainProb = rainArray.optInt(0, 10)
                    }
                }
            }

            Result.success(
                WeatherTelemetry(
                    temperature = temp,
                    relativeHumidity = humidity,
                    windSpeed = wind,
                    rainProbability = rainProb,
                    weatherCode = code,
                    district = district,
                    isSimulated = false,
                    simulationLabel = null
                )
            )
        } catch (e: Exception) {
            Log.e("OpenMeteoRepository", "Error fetching weather: ${e.message}", e)
            Result.success(getFallbackTelemetry(district, "Network error: regional fallback"))
        }
    }

    fun getFallbackTelemetry(district: District, note: String? = null): WeatherTelemetry {
        return WeatherTelemetry(
            temperature = 29.5,
            relativeHumidity = 58,
            windSpeed = 12.0,
            rainProbability = 18,
            weatherCode = 1,
            district = district,
            isSimulated = false,
            simulationLabel = note
        )
    }

    fun getCalmSimulation(district: District): WeatherTelemetry {
        return WeatherTelemetry(
            temperature = 27.5,
            relativeHumidity = 50,
            windSpeed = 6.2,
            rainProbability = 8,
            weatherCode = 0,
            district = district,
            isSimulated = true,
            simulationLabel = "Simulate Calm (6 km/h wind, 8% rain)"
        )
    }

    fun getGaleSimulation(district: District): WeatherTelemetry {
        return WeatherTelemetry(
            temperature = 31.0,
            relativeHumidity = 45,
            windSpeed = 26.5,
            rainProbability = 15,
            weatherCode = 2,
            district = district,
            isSimulated = true,
            simulationLabel = "Simulate Gale (26.5 km/h wind)"
        )
    }

    fun getHeavyRainSimulation(district: District): WeatherTelemetry {
        return WeatherTelemetry(
            temperature = 24.0,
            relativeHumidity = 88,
            windSpeed = 22.0,
            rainProbability = 82,
            weatherCode = 63,
            district = district,
            isSimulated = true,
            simulationLabel = "Simulate Heavy Rain (82% rain)"
        )
    }

    fun getStormSimulation(district: District): WeatherTelemetry {
        return WeatherTelemetry(
            temperature = 22.0,
            relativeHumidity = 92,
            windSpeed = 52.0,
            rainProbability = 89,
            weatherCode = 95,
            district = district,
            isSimulated = true,
            simulationLabel = "Simulate Squall / Storm (52 km/h wind)"
        )
    }
}
