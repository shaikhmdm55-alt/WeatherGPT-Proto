package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Agricultural Forest Green Theme
val AgriDarkForest = Color(0xFF0D2818)
val AgriDeepGreen = Color(0xFF1B4332)
val AgriEmerald = Color(0xFF2D6A4F)
val AgriLeafGreen = Color(0xFF40916C)
val AgriMintAccent = Color(0xFF74C69D)
val AgriPaleGreen = Color(0xFFD8F3DC)

// Status & Alert Colors (High Contrast)
val HazardRed = Color(0xFFDC2626)
val HazardRedDark = Color(0xFF7F1D1D)
val HazardRedBg = Color(0xFFFEE2E2)

val WarningAmber = Color(0xFFD97706)
val WarningAmberDark = Color(0xFF78350F)
val WarningAmberBg = Color(0xFFFEF3C7)

val SafeEmerald = Color(0xFF059669)
val SafeEmeraldDark = Color(0xFF064E3B)
val SafeEmeraldBg = Color(0xFFD1FAE5)

// Neutral & Card Colors
val CardLightBg = Color(0xFFFFFFFF)
val SurfaceDark = Color(0xFF081C15)
val SurfaceCardDark = Color(0xFF133924)
val SurfaceBorder = Color(0xFF265A3B)
val TextPrimaryDark = Color(0xFF0F172A)
val TextSecondaryDark = Color(0xFF475569)
val TextPrimaryLight = Color(0xFFF8FAFC)
val TextSecondaryLight = Color(0xFFCBD5E1)
val GoldWheat = Color(0xFFFFD166)
