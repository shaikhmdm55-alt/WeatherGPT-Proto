package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.AlertSeverity
import com.example.data.Language
import com.example.data.PRESET_DISTRICTS
import com.example.data.WeatherTelemetry
import com.example.logic.AgriDecisionEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("WeatherGPT", appName)
  }

  @Test
  fun `test safe spraying window guardrail`() {
    val telemetry = WeatherTelemetry(
      temperature = 28.0,
      relativeHumidity = 55,
      windSpeed = 10.0, // <= 15 km/h
      rainProbability = 15, // <= 30%
      weatherCode = 0,
      district = PRESET_DISTRICTS[0]
    )
    val decision = AgriDecisionEngine.evaluate(telemetry, Language.ENGLISH)
    assertEquals(AlertSeverity.SAFE, decision.severity)
    assertTrue(decision.statusTitle.contains("SAFE SPRAYING WINDOW"))
  }

  @Test
  fun `test spraying moratorium guardrail when wind is high`() {
    val telemetry = WeatherTelemetry(
      temperature = 30.0,
      relativeHumidity = 45,
      windSpeed = 22.0, // > 15 km/h
      rainProbability = 10,
      weatherCode = 1,
      district = PRESET_DISTRICTS[0]
    )
    val decision = AgriDecisionEngine.evaluate(telemetry, Language.HINDI)
    assertEquals(AlertSeverity.SPRAY_MORATORIUM, decision.severity)
    assertTrue(decision.statusTitle.contains("रोक"))
  }

  @Test
  fun `test convective storm alert guardrail`() {
    val telemetry = WeatherTelemetry(
      temperature = 22.0,
      relativeHumidity = 90,
      windSpeed = 50.0, // > 45 km/h
      rainProbability = 85,
      weatherCode = 95,
      district = PRESET_DISTRICTS[0]
    )
    val decision = AgriDecisionEngine.evaluate(telemetry, Language.GUJARATI)
    assertEquals(AlertSeverity.STORM_ALERT, decision.severity)
    assertTrue(decision.statusTitle.contains("વાવાઝોડા"))
  }
}

